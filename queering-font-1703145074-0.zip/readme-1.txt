Queering is free and open source; donations are optional and downloads of this font cover all usage, for-profit or otherwise. This font is considered experimental and will be updated regularly as it develops.

Queering is a bold display font inspired protest posters, queer publications and underground LGBTQIA+ paraphernalia. It’s built with a set of unicode emojis and symbols to add in-line. The name, Queering, comes from the activity of ‘Queering a Space’ — transgressing what are seen as fixed categories — such as gender and sexuality. Queering is intended to be an open-source font with inclusivity in mind.

Queering is free to download & pay-what-you-want, with all proceeds benefiting the Ali Forney LGBTQ+ Center in Harlem.

https://adamnac.gumroad.com/l/queering

Full Project

https://www.adamnac.com/queering